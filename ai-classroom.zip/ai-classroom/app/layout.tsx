import './globals.css';
export const metadata={title:'AI Classroom'};
export default function L({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
